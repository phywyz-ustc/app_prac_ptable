import requests
from bs4 import BeautifulSoup
import json
#basic functions
def Num2Name1(num):
    url = "https://ptable.com/?lang=en#Properties"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'}) + soup.findAll('li', {'class': 'Liquid'})
    for i in elements:
        if (i.find('b').text == str(num)):
            name1= i.abbr.text
    return name1

def Num2Name2(num):
    url = "https://ptable.com/?lang=en#Properties"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            name2 =i.em.text
    return name2

def Num2Wei(num):
    url = "https://ptable.com/?lang=en#Properties"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            wei = i.data.text
    return wei

def Num2State(num):
    url = "https://ptable.com/?lang=en#Properties"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            state = i.get("class")
    return state[2]

def Num2Oxista(num):
    url = "https://ptable.com/?lang=en#Electrons/OxidationStates"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            oxista = i.data.text
    return oxista
    

def Num2Numiso(num):
    url = "https://ptable.com/?lang=en#Isotopes/Count"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            numiso = i.data.text
    return numiso

def Num2Numcom(num):
    url = "https://ptable.com/?lang=en#Compounds"
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")

    elements = soup.findAll('li', {'class': 'Gas'}) + soup.findAll(
    'li', {'class': 'Solid'}) + soup.findAll('li', {'class': 'UnknownState'})
    for i in elements:
        if (i.find('b').text == str(num)):
            numcom = i.data.text
    return numcom    

def Text2Com(text):
    url = "https://ptable.com/JSON/compounds/formula=" + text.replace(" ", '')
    response = requests.get(url)
    text=''
    if response.status_code != 404:
        data = json.loads(response.content)
        count=0
        for i in data['matches']:
            if count<5:
                text=text+'\n'+i['molecularformula']
                count=count+1
        return text
    else:
        return 'no!'

#classes for elements and Compounds
class ResultEle:
    def __init__(self,num):
        self.num =num
    def name1(self):
        return Num2Name1(self.num)
    def name2(self):
        return Num2Name2(self.num)
    def weight(self):
        return Num2Wei(self.num)
    def state(self):
        return Num2State(self.num)
    def oxista(self):
        return Num2Oxista(self.num)
    def numiso(self):
        return Num2Numiso(self.num)
    def numcom(self):
        return Num2Numcom(self.num)

class ResultCom:
    def __init__(self,text):
        self.text=Text2Com(text)


#functions with main.py
def GetEleNum(number):
    result = ResultEle(number)
    return result

def GetComText(text):
    result = ResultCom(text)
    return result

